<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Backend\User;
use App\Models\Backend\Provinces;
use App\Models\Backend\District;
use App\Models\Backend\SubDistrict;
use Yajra\DataTables\DataTables;

class AjaxController extends Controller
{
    public function get_district(Request $request)
    {
        $id = $request->id;
        $data = '';
        $result = District::where(['_id'=>$id])->get();
        foreach($result as $row){
            $data.="<option value=".$row->id.">".$row->name_th."</option>";
        }
        echo $data;
    }
    public function get_subdistrict(Request $request)
    {
        $id = $request->id;
        $result = SubDistrict::where(['_id'=>$id])->get();
        $data = '';
        foreach($result as $row)
        {
            $data.="<option value=".$row->id.">".$row->name_th."</option>";
        }
        echo $data;
    }
    public function get_zipcode(Request $request)
    {
        $id = $request->id;
        $result = SubDistrict::where(['id'=>$id])->get();
        $data = '';
        foreach($result as $row){
            $data = $row->zipcode;
        }
        echo $data;
    }
    
    public function get_province_en(Request $request)
    {
        $id = $request->id;
        $result = Provinces::where(['id'=>$id])->get();
        $name_en = '';
        foreach($result as $row){
            $name_en= $row->name_en;    
        }
        echo $name_en;
    }
    public function get_district_en(Request $request)
    {
        $id = $request->id;
        $result = District::where(['id'=>$id])->get();
        $name_en = '';
        foreach($result as $row){
            $name_en= $row->name_en;    
        }
        echo $name_en;
    }
    public function get_subdistrict_en(Request $request)
    {
        $id = $request->id;
        $result = SubDistrict::where(['id'=>$id])->get();
        $name_en = '';
        foreach($result as $row){
            $name_en= $row->name_en;    
        }
        echo $name_en;
    }
    
    public function get_province_th(Request $request)
    {
        $id = $request->id;
        $result = Provinces::where(['id'=>$id])->get();
        $name_th = '';
        foreach($result as $row){
            $name_th = $row->name_th;    
        }
        echo $name_th;
    }
    public function get_district_th(Request $request)
    {
        $id = $request->id;
        $result = District::where(['id'=>$id])->get();
        $name_th = '';
        foreach($result as $row){
            $name_th = $row->name_th;    
        }
        echo $name_th;
    }
    public function get_subdistrict_th(Request $request)
    {
        $id = $request->id;
        $result = SubDistrict::where(['id'=>$id])->get();
        $name_th = '';
        foreach($result as $row){
            $name_th = $row->name_th;    
        }
        echo $name_th;
    }
}
