<div id="sidebar-menu">
    <!-- Left Menu Start -->
    <ul class="metismenu list-unstyled" id="side-menu">
        <li class="menu-title">เมนูทั่วไป</li>
        <li>
            <a href="<?php echo e(url("webpanel")); ?>" class=" waves-effect">
                <i class="bx bx-home-circle"></i>
                <span>Dashboard (ภาพรวม)</span>
            </a>
        </li>

        <li class="menu-title">เมนูการจัดการ</li>
        <?php $menu = \App\Models\Backend\MenuModel::where(['position'=>'main','status'=>'on'])->orderBy('sort')->get(); ?>
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $second = \App\Models\Backend\MenuModel::where('_id',$m->id)->get(); ?>
            <li>
                <a href="<?php if(count($second) > 0): ?> javascript:void(0); <?php else: ?> webpanel<?php echo $m->url; ?> <?php endif; ?>" class="<?php if(count($second) > 0): ?> has-arrow <?php endif; ?>  waves-effect">
                    <i class="<?php echo $m->icon; ?>"></i>
                    <span><?php echo e($m->name); ?></span>
                </a>
                <?php if(count($second)>0): ?>
                <ul class="sub-menu" aria-expanded="false">
                    <?php $__currentLoopData = $second; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="webpanel<?php echo e($s->url); ?>"><?php echo e($s->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>     
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <li class="menu-title">เมนูผู้ดูแลระบบ</li>
        <li>
            <a href="<?php echo e(url("$segment/menu")); ?>" class=" waves-effect">
                <i class="bx bx-menu-alt-right"></i>
                <span>รายการเมนู</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url("$segment/user")); ?>" class=" waves-effect">
                <i class="bx bx-user"></i>
                <span>รายการผู้ดูแล</span>
            </a>
        </li>
    </ul>

    
</div><?php /**PATH C:\xampp\htdocs\orange\laravel8\blog\resources\views/back-end/layout/menu.blade.php ENDPATH**/ ?>