<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © ORANGE TECHNOLOGY SOLUTION
            </div>
            
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\orange_template\resources\views/back-end/layout/footer.blade.php ENDPATH**/ ?>