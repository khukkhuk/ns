<!doctype html>
<html lang="en">

<head>
    <base href="<?php echo e(url('')); ?>">
    <meta charset="utf-8" />
    <title> Skote - Responsive Bootstrap 4 Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="backend/images/favicon.ico">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="backend/css/bootstrap-dark.min.css" id="bootstrap-dark" rel="stylesheet" type="text/css" />
    <link href="backend/css/bootstrap.min.css" id="bootstrap-light" rel="stylesheet" type="text/css" />
    <link href="backend/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="backend/css/app-rtl.min.css" id="app-rtl" rel="stylesheet" type="text/css" />
    <link href="backend/css/app-dark.min.css" id="app-dark" rel="stylesheet" type="text/css" />
    <link href="backend/css/app.min.css" id="app-light" rel="stylesheet" type="text/css" />
    <!-- DataTables -->
    <link rel="stylesheet" type="text/css" href="backend/libs/datatables/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="backend/libs/toastr/toastr.min.css">

    <link href="backend/css/custom.css" id="app-light" rel="stylesheet" type="text/css" />
    <?php if(@$css): ?>
        <?php $__currentLoopData = $css; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $css): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <link href="<?php echo e($css); ?>" rel="stylesheet">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</head>

<body data-sidebar="dark">
    <div id="preloader">
        <div id="status">
            <div class="spinner-chase">
                <div class="chase-dot"></div>
                <div class="chase-dot"></div>
                <div class="chase-dot"></div>
                <div class="chase-dot"></div>
                <div class="chase-dot"></div>
                <div class="chase-dot"></div>
            </div>
        </div>
    </div>
    <!-- Begin page -->
    <div id="layout-wrapper">
        <?php echo $__env->make("$prefix.layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- ========== Left Sidebar Start ========== -->
        <div class="vertical-menu">

            <div data-simplebar class="h-100">

                <!--- Sidemenu -->
                <?php echo $__env->make("$prefix.layout.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Sidebar -->
            </div>
        </div>
        <!-- Left Sidebar End -->

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <?php echo $__env->make("$prefix.pages.$folder.page-$page", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->
            <?php echo $__env->make("$prefix.layout.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- ============================================================== -->
        <!-- End Right content here -->
        <!-- ============================================================== -->
    </div>
    <!-- END wrapper -->

    <!-- Right Sidebar -->
    <?php echo $__env->make("$prefix.layout.right-sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END Right Sidebar -->


    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <!-- JAVASCRIPT -->
    <script src="backend/libs/jquery/jquery.min.js"></script>
    <script src="backend/libs/bootstrap/bootstrap.min.js"></script>
    <script src="backend/libs/metismenu/metismenu.min.js"></script>
    <script src="backend/libs/simplebar/simplebar.min.js"></script>
    <script src="backend/libs/node-waves/node-waves.min.js"></script>
    <script type="text/javascript">$(function() { $.ajaxSetup({headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}}); });</script>

    <!-- Plugins DataTables js -->
    <script src="backend/libs/datatables/datatables.min.js"></script>
    <script src="backend/libs/jszip/jszip.min.js"></script>
    <script src="backend/libs/pdfmake/pdfmake.min.js"></script>

    <!-- Magnific Popup -->
    <script src="backend/libs/toastr/toastr.min.js"></script>

    <!-- App js -->
    <script src="backend/js/app.min.js"></script>

    <!-- Script Others -->
    <?php if(@$js): ?>
    <?php $__currentLoopData = $js; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script <?php $__currentLoopData = $js[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($k); ?>="<?php echo e($v); ?>" <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> ></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\orange_template\resources\views/back-end/pages/employee/index.blade.php ENDPATH**/ ?>