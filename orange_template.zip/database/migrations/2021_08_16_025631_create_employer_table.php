<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employer', function (Blueprint $table) {
            $table->id();

            $table->string('type',100);
            $table->string('id_card',100);
            $table->string('legal_number',13);
            $table->string('company_name',100);

            $table->string('prefix_th',10);
            $table->string('name_th',50);
            $table->string('surname_th',50);
            $table->string('nickname_th',20);

            $table->string('prefix_en',10);
            $table->string('name_en',50);
            $table->string('surname_en',50);
            $table->string('nickname_en',20);

            $table->string('address_th',50);
            $table->string('group_th',10);
            $table->string('road_th',50);
            $table->string('province_id',10);
            $table->string('district_id',10);
            $table->string('subdistrict_id',10);

            $table->string('address_en',50);
            $table->string('group_en',10);
            $table->string('road_en',20);
            $table->string('province_en',10);
            $table->string('district_en',10);
            $table->string('subdistrict_en',10);

            $table->string('zipcode',10);
            $table->string('tel',100);
            $table->string('email',100);

            
            $table->string('delete_status',10);
            $table->string('created',10);
            $table->string('updated',10);
            $table->string('deleted',10);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employer');
    }
}
