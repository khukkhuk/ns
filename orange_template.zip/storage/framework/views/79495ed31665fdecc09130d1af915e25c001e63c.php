<div class="fadeOut">
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-0 font-size-18">แก้ไขข้อมูลเมนู</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url("$segment")); ?>">หน้าแรก</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url("$segment/$folder")); ?>">รายการเมนู</a></li>
                        <li class="breadcrumb-item active">แก้ไขข้อมูลเมนู </li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->


    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">

                                    <form id="menuForm" method="post" action="" onsubmit="return check_add();">                        
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <button class="btn btn-primary" type="submit" name="signup" value="Create">บันทึกข้อมูล</button>
                                            <a class="btn btn-danger" href="<?php echo e(url($segment)); ?>">ยกเลิก</a>
                                        </div>
                                        <hr>   

                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="form-group col-md-6">
                                                        <label for="position">ตำแหน่ง</label>
                                                        <select class="form-control" name="position" id="position">
                                                            <option value="" hidden>กรุณาเลือก</option>
                                                            <option value="main" <?php if($row->position == "main"): ?> selected <?php endif; ?>>เมนูหลัก</option>
                                                            <option value="secondary" <?php if($row->position == "secondary"): ?> selected <?php endif; ?>>เมนูย่อย</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="position">เป็นเมนูย่อยของเมนู :</label>
                                                            <select class="form-control" name="_id" id="_id" <?php if($row->position == "main"): ?> disabled selected <?php endif; ?>>
                                                                <option value="" hidden>กรุณาเลือก</option>
                                                                <?php if($main): ?>
                                                                <?php $__currentLoopData = $main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($c->id); ?>" <?php if($c->id == $row->_id): ?> selected <?php endif; ?>><?php echo e($c->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="icon">Icon</label> :
                                            <small class="text-muted"><a href="<?php echo e(url("$segment/$folder/icon")); ?>" target="_blank">Box Icons</a></small>
                                            <div class="input-group">
                                                <span class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <span id="icon-preview"><i <?php if($row->icon != null): ?> class="<?php echo e(@$row->icon); ?>" <?php endif; ?> ></i></span>
                                                    </span>
                                                </span>
                                                <input class="form-control" id="icon" name="icon" value="<?php echo e(@$row->icon); ?>" type="text" placeholder="icon" autocomplete="off">
                                            </div>                            
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="username">ชื่อเมนู</label>
                                            <input class="form-control" id="name" type="text" name="name" value="<?php echo e(@$row->name); ?>" placeholder="กรุณากรอกชื่อเมนู" autocomplete="off">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="url">ลิงค์เมนู</label>
                                            <input class="form-control" id="url" type="text" name="url" value="<?php echo e(@$row->url); ?>" placeholder="กรุณากรอกลิงค์แสดงผลเมนูเช่น /menu" autocomplete="off">
                                        </div>                        
                                        <hr>
                                        <div class="form-group">
                                            <button class="btn btn-primary" type="submit" name="signup" value="Create">บันทึกข้อมูล</button>
                                            <a class="btn btn-danger" href="<?php echo e(url("$segment/$folder")); ?>">ยกเลิก</a>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div> <!-- end col -->
                    </div> <!-- end row -->

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
    <script>
        
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\orange\laravel8\blog\resources\views/back-end/pages/menu/page-edit.blade.php ENDPATH**/ ?>