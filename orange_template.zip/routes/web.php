<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Webpanel as Webpanel;
use App\Http\Controllers\Frontend as Frontend;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {return view('welcome');});



//====================  ====================
//================  Backend ================
//====================  ====================

Route::get('/', [Webpanel\HomeController::class,'index']);




Route::get('webpanel/login', [Webpanel\AuthController::class,'getLogin']);
Route::post('webpanel/login', [Webpanel\AuthController::class,'postLogin']);
Route::get('webpanel/logout', [Webpanel\AuthController::class,'logOut']);


Route::get('/ajax/get_province_en', [Frontend\AjaxController::class,'get_province_en']);
Route::get('/ajax/get_district_en', [Frontend\AjaxController::class,'get_district_en']);
Route::get('/ajax/get_subdistrict_en', [Frontend\AjaxController::class,'get_subdistrict_en']);
Route::get('/ajax/get_distirct', [Frontend\AjaxController::class,'get_district']);
Route::get('/ajax/get_subdistirct', [Frontend\AjaxController::class,'get_subdistrict']);
Route::get('/ajax/get_zipcode', [Frontend\AjaxController::class,'get_zipcode']);

Route::group(['middleware' => ['Webpanel']], function () {

    Route::prefix('webpanel')->group(function () {
        Route::get('/', [Webpanel\HomeController::class,'index']);


        // === Controller Fixed Webpage ===
        Route::prefix('menu')->group(function(){
            Route::get('/', [Webpanel\MenuController::class,'index']);
            Route::post('/datatable', [Webpanel\MenuController::class,'datatable']);
            Route::get('/add', [Webpanel\MenuController::class,'add']);
            Route::post('/add', [Webpanel\MenuController::class,'insert']);
            Route::get('/{id}', [Webpanel\MenuController::class,'edit'])->where(['id' => '[0-9]+']);
            Route::post('/{id}', [Webpanel\MenuController::class,'update'])->where(['id' => '[0-9]+']);
            Route::get('/icon', [Webpanel\MenuController::class,'icon']);
            Route::get('/status/{id}', [Webpanel\MenuController::class,'status'])->where(['id' => '[0-9]+']);
            Route::get('/sub_status/{id}', [Webpanel\MenuController::class,'sub_status'])->where(['id' => '[0-9]+']);
            Route::get('/destroy', [Webpanel\MenuController::class,'destroy']);
        });

        Route::prefix('user')->group(function(){
            Route::get('/', [Webpanel\UserController::class,'index']);
            Route::post('/datatable', [Webpanel\UserController::class,'datatable']);
            Route::get('/add', [Webpanel\UserController::class,'add']);
            Route::post('/add', [Webpanel\UserController::class,'insert']);
            Route::get('/{id}', [Webpanel\UserController::class,'edit'])->where(['id' => '[0-9]+']);
            Route::post('/{id}', [Webpanel\UserController::class,'update'])->where(['id' => '[0-9]+']);
            Route::get('/status/{id}', [Webpanel\UserController::class,'status'])->where(['id' => '[0-9]+']);
            Route::get('/destroy', [Webpanel\UserController::class,'destroy']);
        });

        
        Route::prefix('customer')->group(function(){
            Route::get('/', [Webpanel\CustomerController::class,'index']);
            Route::post('/datatable', [Webpanel\CustomerController::class,'datatable']);
            Route::get('/add', [Webpanel\CustomerController::class,'add']);
            Route::get('/employee/{id}', [Webpanel\CustomerController::class,'index_employee']);
            Route::post('/datatable_employee/{id}', [Webpanel\CustomerController::class,'datatable_employee']);
            Route::get('/add_employerdetail/{id}', [Webpanel\CustomerController::class,'add_employer']);
            Route::post('/add', [Webpanel\CustomerController::class,'insert']);
            Route::get('/{id}', [Webpanel\CustomerController::class,'edit'])->where(['id' => '[0-9]+']);
            Route::post('/{id}', [Webpanel\CustomerController::class,'update'])->where(['id' => '[0-9]+']);
            Route::get('/status/{id}', [Webpanel\CustomerController::class,'status'])->where(['id' => '[0-9]+']);
            Route::get('/destroy', [Webpanel\CustomerController::class,'destroy']);
        });

        Route::prefix('employee')->group(function(){
            Route::get('/index/{id}', [Webpanel\EmployeeController::class,'index']);
            Route::post('/datatable/{id}', [Webpanel\EmployeeController::class,'datatable']);
            Route::get('/add/{id}', [Webpanel\EmployeeController::class,'add']);
            Route::post('/add/{id}', [Webpanel\EmployeeController::class,'insert']);
            Route::get('/{id}', [Webpanel\EmployeeController::class,'edit']);
            Route::post('/{id}', [Webpanel\EmployeeController::class,'update']);
        });
        Route::prefix('follower')->group(function(){
            Route::get('/index/{id}', [Webpanel\FollowerController::class,'index']);
            Route::post('/datatable/{id}', [Webpanel\FollowerController::class,'datatable']);
            Route::get('/add/{id}', [Webpanel\FollowerController::class,'add']);
            Route::post('/add/{id}', [Webpanel\FollowerController::class,'add']);
            Route::get('/{id}', [Webpanel\FollowerController::class,'edit']);
            Route::post('/{id}', [Webpanel\FollowerController::class,'update']);
            Route::get('/destroy/{id}',[Webpanel\FollowerController::class,'destroy']);
        });
        
        Route::prefix('pinkcard')->group(function(){
            Route::get('/', [Webpanel\PinkcardController::class,'index']);
            Route::post('/datatable', [Webpanel\PinkcardController::class,'datatable']);
            Route::get('/add_pinkcard', [Webpanel\PinkcardController::class,'add_pinkcard']);
            Route::get('/health_check', [Webpanel\PinkcardController::class,'health_check']);
            Route::get('/Visa', [Webpanel\PinkcardController::class,'Visa']);
            Route::get('/work_permit', [Webpanel\PinkcardController::class,'work_permit']);
            Route::get('/pinkcard', [Webpanel\PinkcardController::class,'pinkcard']);
            Route::get('/nationality_proof', [Webpanel\PinkcardController::class,'nationality_proof']);
            Route::get('/destroy', [Webpanel\PinkcardController::class,'destroy']);
        });
        // === End Fixed Controller ===

    });
    
}); 